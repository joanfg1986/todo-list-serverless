import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='joanfg1986',
    application_name='todo-list-serverless',
    app_uid='yDB251f5wCq4FXwdsr',
    org_uid='a976e823-b8d8-480a-a3dc-1c2df688fe6d',
    deployment_uid='fd184629-f33b-4558-a20a-2420b16f9fb8',
    service_name='api-rest',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.5.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'api-rest-dev-create', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/create.create')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
